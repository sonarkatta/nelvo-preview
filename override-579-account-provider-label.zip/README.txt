override-579-account-provider-label
Fix: account page no longer shows "Signed in with Google" for email/password accounts.
Source: account.html bindReal() now reads user.providerData[0].providerId and renders
"Signed in with Google" only for google.com, otherwise "Signed in with email".
Wrapped with the current dual gate slots (W1 owner / W2 Razorpay review), payload verified
byte-identical to live before rewrap; dual-decrypt round-trip verified after.
Plain fixed source: qa-candidates/2026-11-10 in taarv-masters-backup.
