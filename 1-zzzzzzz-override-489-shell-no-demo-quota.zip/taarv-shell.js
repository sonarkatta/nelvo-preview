/* TAARV shared shell: header + footer for every tool page. One place for the live tool count. */
(function(){
if(window.__taarvShell)return;window.__taarvShell=1;
var COUNT=38;try{var _t=document.createElement('script');_t.src='/taarv-text.js?v=1';document.head.appendChild(_t)}catch(e){} /* <- the ONLY place the tool count lives for tool pages */
var LIGHT='/taarv-master-light.png?v=master-20261011-r1';
var css='@media screen{'+
'.tv-hdr{display:block}'+
'.tv-hdr *{box-sizing:border-box}'+
'.tv-in{max-width:1280px;margin:0 auto;height:56px;padding:0 32px;display:flex;align-items:center;justify-content:space-between;gap:16px}'+
'.tv-brand{display:flex;align-items:center;flex:none}.tv-brand img{height:30px;width:auto;display:block}'+
'.tv-nav{display:flex;align-items:center;gap:32px}'+
'.tv-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}'+
'.tv-nav a{font-size:11px;letter-spacing:.14em;color:#6e6e73;text-decoration:none}.tv-nav a:hover{color:#000}'+
'.tv-clock{display:flex;align-items:center;gap:8px;font-size:10px;color:#86868b}.tv-dot{width:4px;height:4px;border-radius:50%;background:#00c950;animation:tvp 2s infinite}@keyframes tvp{50%{opacity:.35}}'+
'.tv-r{display:flex;align-items:center;gap:8px}'+
'.tv-pill{height:32px;display:inline-flex;align-items:center;border:1px solid #d9d9de;background:#fff;border-radius:999px;padding:0 16px;font-size:12px;font-weight:500;color:#1d1d1f;text-decoration:none;white-space:nowrap}.tv-pill:hover{border-color:#000}'+
'.tv-pill.tv-count{font-size:11px;letter-spacing:.08em;font-weight:400}'+
'.tv-dm{display:none;font-size:10px;letter-spacing:.08em;font-weight:400}.tv-pill.tv-go{background:#000;border-color:#000;color:#fff;font-weight:600}.tv-pill.tv-go:hover{background:#1a1a1a}'+
'.tv-demo{display:flex;justify-content:flex-end;max-width:1280px;margin:0 auto;padding:0 32px 8px}.tv-demo a{font-size:10px;letter-spacing:.1em;color:#6e6e73;text-decoration:none;border:1px solid #d9d9de;border-radius:999px;padding:6px 13px;background:#fff}'+
'.tv-ftr{width:100vw;margin-left:calc(50% - 50vw);margin-top:56px;border-top:1px solid #e8e8ec;background:#fbfbfd;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;color:#1d1d1f;position:relative;z-index:1}.tv-ftr *{box-sizing:border-box}'+
'.tv-cols{max-width:1280px;margin:0 auto;padding:48px 32px;display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:40px;background:#fff}'+
'.tv-cols p{font-size:13px;line-height:1.6;color:#6e6e73;max-width:280px;margin:14px 0 0}'+
'.tv-cols h4{font-size:10px;letter-spacing:.18em;color:#6e6e73;margin:0 0 16px;font-weight:500}.tv-cols ul{list-style:none;margin:0;padding:0}.tv-cols li{font-size:13px;line-height:1.4;margin:0 0 8px}.tv-cols a{color:#1d1d1f;text-decoration:none}.tv-cols a:hover{text-decoration:underline}'+
'.tv-word{border-top:1px solid #e8e8ec;padding:56px 16px 24px;text-align:center;overflow:hidden}.tv-word img{display:block;width:min(830px,92%);height:auto;margin:0 auto}'+
'.tv-sub{display:flex;justify-content:center;gap:24px;margin-top:18px;font-size:11px;letter-spacing:.22em;color:#6e6e73}'+
'.tv-strip{border-top:1px dashed #d9d9de}.tv-strip>div{max-width:1280px;margin:0 auto;padding:12px 32px;display:flex;justify-content:space-between;gap:16px;font-size:9px;letter-spacing:.14em;color:#86868b}.tv-strip span+span{margin-left:24px}'+
'}'+
'@media screen and (max-width:767px){.tv-dm{display:inline-flex}.tv-in{height:auto;padding:10px 16px 6px;flex-wrap:wrap}.tv-nav{display:none}.tv-brand img{height:26px}'+
'.tv-r{order:3;width:calc(100% + 32px);margin:0 -16px;padding:4px 16px 8px;overflow-x:auto;white-space:nowrap;-webkit-overflow-scrolling:touch;scrollbar-width:none}.tv-r::-webkit-scrollbar{display:none}'+
'.tv-go{position:absolute;right:16px;top:10px;height:34px}.tv-demo{display:none}'+
'.tv-cols{grid-template-columns:1fr 1fr;padding:32px 16px;gap:28px}.tv-cols>div:first-child{grid-column:1/-1}.tv-word{padding:36px 12px 16px}.tv-sub{flex-direction:column;align-items:center;gap:6px;font-size:10px}.tv-strip>div{padding:12px 16px;flex-direction:column;gap:6px}.tv-strip .tv-x{display:none}}'+
'@media print{.tv-hdr,.tv-ftr{display:none!important}}';
function el(t,c,h){var e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function clock(){try{return new Date().toLocaleTimeString('en-GB',{timeZone:'Asia/Kolkata',hour12:false})+' IST'}catch(e){return ''}}
function build(){
 if(document.querySelector('.tv-hdr'))return;
 var st=el('style');st.id='tv-shell-css';st.textContent=css;document.head.appendChild(st);
  var H=el('div','tv-hdr');var sr=H.attachShadow({mode:'open'});
 sr.innerHTML='<link rel="stylesheet" href="/taarv-header.css?v=1"><div class="tvroot"><header class="sticky top-0 z-50 border-b border-[var(--line)] bg-[var(--bg)]/80 backdrop-blur-[12px]" style="padding-top: var(--safe-area-inset-top);"><div class="mx-auto flex h-[56px] max-w-[1280px] items-center justify-between px-6 md:px-8"><a href="/" class="nelvo-brand"><img src="/taarv-master-light.png?v=master-20261011-r1" alt="TAARV - The Tool Factory"></a><nav class="hidden items-center gap-8 md:flex"><a href="/#factory" class="mono text-[11px] tracking-[0.14em] text-[var(--muted)] hover:text-black transition-colors">FACTORY_FLOOR</a><a href="/manifesto/" class="mono text-[11px] tracking-[0.14em] text-[var(--muted)] hover:text-black transition-colors">MANIFESTO</a><div class="mono flex items-center gap-2 text-[10px] text-[var(--muted-2)]"><span class="h-[4px] w-[4px] animate-pulse rounded-full bg-[#00C950]"></span><span id="tv-clk">'+clock()+'</span></div></nav><button class="nelvo-mobile-menu" type="button" aria-label="Open menu" aria-expanded="false">\u2630</button><div class="flex items-center gap-2 nelvo-header-actions"><button class="nelvo-search-trigger" aria-label="Search all '+COUNT+' tools" data-go="/#factory">Search</button><button class="mono hidden h-8 items-center rounded-full border border-[var(--line)] bg-white px-4 text-[11px] tracking-[0.08em] md:flex hover:border-black transition-colors" data-go="/#factory">'+COUNT+' READY \u2022 LOCAL TOOLS</button><a href="/pricing/" class="nelvo-header-login nelvo-packages-nav">Packages</a><a href="/login/" class="nelvo-header-login">Login</a><button class="h-8 rounded-full bg-black px-4 text-[11px] font-[600] tracking-[-0.01em] text-white hover:bg-[#1a1a1a] transition-colors" data-go="/">Enter</button></div></div></header></div>';
 var hd=sr.querySelector('header');
 var mq=document.createElement('style');mq.textContent='@media(max-width:900px){header.sticky{background:#fff!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important}}';sr.appendChild(mq);
 sr.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-go]');if(b){location.href=b.getAttribute('data-go');return}var m=e.target.closest&&e.target.closest('.nelvo-mobile-menu');if(m){var o=hd.classList.toggle('nelvo-menu-open');m.setAttribute('aria-expanded',o)}});
 document.documentElement.style.setProperty('--tv-hdr-pad','80px');
 var ps=document.createElement('style');ps.id='tv-pad';document.head.appendChild(ps);
 function fitPad(){var q=hd.getBoundingClientRect();var px=Math.max(80,Math.ceil(q.bottom)+10);ps.textContent='@media screen{body{padding-top:'+px+'px!important}}@media print{.tv-hdr,.tv-ftr{display:none!important}body{padding-top:0!important}}'}
 fitPad();window.addEventListener('resize',fitPad);window.addEventListener('load',fitPad);setTimeout(fitPad,400);setTimeout(fitPad,1500);if(window.ResizeObserver)new ResizeObserver(fitPad).observe(hd);
 var old=document.querySelectorAll('body>header,body>nav,body>.topbar,body>.top,body>.site-header');
 for(var i=0;i<old.length;i++){var o=old[i];if(o.classList.contains('tv-hdr'))continue;if(o.querySelector('h1,h2,canvas,input,textarea,select'))continue;o.style.display='none'}
 var wrapH=document.querySelectorAll('body>.wrap>header,body>main>header,body>div>header');
 for(var j=0;j<wrapH.length;j++){var w=wrapH[j];if(w.querySelector('h1,h2,canvas,input,textarea,select,button'))continue;if(w.querySelector('img,nav'))w.style.display='none'}
 document.body.insertBefore(H,document.body.firstChild);
 setInterval(function(){var c=H.shadowRoot.getElementById('tv-clk');if(c)c.textContent=clock()},1000);
 /* footer */
 var oldf=document.querySelectorAll('body>footer,body>.foot,main>footer,.wrap>footer,.wrap>.foot');
 for(var k=0;k<oldf.length;k++){var f=oldf[k];if(f.querySelector('input,textarea,select,button,canvas'))continue;f.style.display='none'}
 var F=el('footer','tv-ftr');
 F.innerHTML='<div class="tv-cols"><div><a href="/"><img src="'+LIGHT+'" alt="TAARV" style="height:34px;width:auto;display:block"></a><p>Ultra-premium tool factory. Minimal, industrial, precise. Built for people who make things.</p></div>'+
 '<div><h4 class="tv-mono">MACHINES</h4><ul><li><a href="/#factory">All '+COUNT+' Tools</a></li><li><a href="/#factory">New Releases</a></li><li><a href="/#factory">Changelog</a></li><li><a href="/#factory">Roadmap</a></li></ul></div>'+
 '<div><h4 class="tv-mono">FACTORY</h4><ul><li><a href="/manifesto/">Manifesto</a></li><li>System Status</li><li>Privacy (Local-only)</li><li>Contact</li></ul></div></div>'+
 '<div class="tv-word"><img src="'+LIGHT+'" alt="TAARV"><div class="tv-sub tv-mono"><span>THE TOOL FACTORY</span><span>'+COUNT+' MACHINES - ONE FACTORY</span></div></div>'+
 '<div class="tv-strip"><div class="tv-mono"><div style="display:flex;padding:0;max-width:none;margin:0"><span>\u00a9 2026 TAARV</span><span class="tv-x">MADE IN THE FACTORY</span></div><span>'+COUNT+' READY / LOCAL TOOLS \u2014 BUILD 2.0</span></div></div>';
 F.querySelector('.tv-cols').style.borderTop='1px solid #e8e8ec';document.body.appendChild(F);document.documentElement.style.overflowX='clip';try{var cs=getComputedStyle(document.body);F.style.marginBottom='-'+cs.paddingBottom}catch(e){}
 /* LIQUID GLASS (light, original palette): soft colour glow behind, clear glass cards in front */
 (function(){var gl=document.createElement('style');gl.id='tv-glass';gl.textContent=
 '@media screen{html.tv-glass{background-color:#f3f3f7!important;background-image:radial-gradient(55vmax 45vmax at 8% -8%,rgba(120,140,255,.30),transparent 62%),radial-gradient(50vmax 42vmax at 96% 6%,rgba(255,150,200,.26),transparent 62%),radial-gradient(55vmax 45vmax at 80% 105%,rgba(80,210,190,.24),transparent 60%),radial-gradient(45vmax 40vmax at -4% 92%,rgba(255,200,120,.24),transparent 60%)!important;background-attachment:fixed!important}'+
 'html.tv-glass body{background:transparent!important}'+
 'html.tv-glass :is(.card,.panel,.pnl,.box,.side,.stage,.dock,.bar){background:linear-gradient(135deg,rgba(255,255,255,.66),rgba(255,255,255,.34) 45%,rgba(255,255,255,.5))!important;border:1px solid rgba(255,255,255,.85)!important;-webkit-backdrop-filter:blur(10px) saturate(190%);backdrop-filter:blur(10px) saturate(190%);box-shadow:inset 0 1.5px 0 rgba(255,255,255,.95),inset 0 -1px 0 rgba(255,255,255,.5),inset 0 0 18px rgba(255,255,255,.35),0 1px 2px rgba(20,20,40,.06),0 18px 44px rgba(40,40,90,.14)!important}'+
 'html.tv-glass :is(input[type=text],input[type=number],input[type=email],input[type=tel],input[type=date],textarea,select){background:rgba(255,255,255,.55)!important;border:1px solid rgba(255,255,255,.9)!important;box-shadow:inset 0 1px 2px rgba(20,20,40,.1)!important}'+
 'html.tv-glass :is(.chips button,.mini,.seg){background:linear-gradient(160deg,rgba(255,255,255,.8),rgba(255,255,255,.4))!important;border:1px solid rgba(255,255,255,.9)!important;box-shadow:inset 0 1px 0 #fff,0 2px 8px rgba(20,20,40,.08)!important}'+
 '.tv-ftr{background:linear-gradient(180deg,rgba(255,255,255,.6),rgba(255,255,255,.3))!important;-webkit-backdrop-filter:blur(10px) saturate(190%);backdrop-filter:blur(10px) saturate(190%);box-shadow:inset 0 1.5px 0 rgba(255,255,255,.95)}.tv-ftr .tv-cols,.tv-ftr .tv-word{background:transparent!important}}';
 document.head.appendChild(gl);document.documentElement.classList.add('tv-glass');})();

}
if(document.body)build();else document.addEventListener('DOMContentLoaded',build);
window.addEventListener('load',build);
})();

/* TAARV design system loader: restyles the classic tool pages (grey grid, mono labels) into the premium skin. */
(function(){try{
 var OLD=' govdoc datawipe photocover pixelclean ';
 var slug=location.pathname.replace(/^\/+|\/+$/g,'').split('/')[0];
 if(OLD.indexOf(' '+slug+' ')<0)return;
 var done=0;function go(){if(done||!document.body)return;done=1;document.documentElement.classList.add('tv-ds');
  var l=document.createElement('link');l.rel='stylesheet';l.href='/taarv-ds.css?v=5';document.head.appendChild(l);}
 go();
}catch(e){}})();
