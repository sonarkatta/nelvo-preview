/* TAARV shared shell: premium header + footer for every tool page. One place for the live tool count. */
(function(){
if(window.__taarvShell)return;window.__taarvShell=1;
var COUNT=38;try{var _t=document.createElement('script');_t.src='/taarv-text.js?v=1';document.head.appendChild(_t)}catch(e){} /* <- the ONLY place the tool count lives for tool pages */
var GOLD='/taarv-gold-logo.png?v=1';
var NAVY='#10234a',NAVY2='#0e1f42',INK='#f5f2ec',MUT='#b6c3da',GOLD1='#c4861a',GOLD2='#f0bf4e';
var PACKAGES='https://nelvo-monetization.sonarkatta.workers.dev/packages';
var css='@media screen{'+
'html,body{background:#10234a!important;background:linear-gradient(180deg,#10234a,#0e1f42 75%) fixed!important}'+
'.tv-hdr{display:block}'+
'.tv-ftr{width:100vw;max-width:none;margin-left:calc(50% - 50vw);margin-top:56px;background:'+NAVY2+';color:'+INK+';font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;position:relative;z-index:1}'+
'.tv-ftr *{box-sizing:border-box}'+
'.tv-cols{max-width:1280px;margin:0 auto;padding:48px 32px;display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:40px}'+
'.tv-cols p{font-size:13px;line-height:1.6;color:'+MUT+';max-width:280px;margin:14px 0 0}'+
'.tv-cols h4{font-size:10px;letter-spacing:.18em;color:'+GOLD2+';margin:0 0 16px;font-weight:500}'+
'.tv-cols ul{list-style:none;margin:0;padding:0}.tv-cols li{font-size:13px;line-height:1.4;margin:0 0 8px}'+
'.tv-cols a{color:'+INK+';text-decoration:none;opacity:.85}.tv-cols a:hover{opacity:1;color:'+GOLD2+'}'+
'.tv-word{border-top:1px solid rgba(255,255,255,.12);padding:48px 16px 20px;text-align:center;overflow:hidden}'+
'.tv-word img{display:block;width:min(560px,86%);height:auto;margin:0 auto}'+
'.tv-sub{display:flex;justify-content:center;gap:24px;margin-top:18px;font-size:11px;letter-spacing:.22em;color:'+MUT+'}'+
'.tv-strip{border-top:1px dashed rgba(255,255,255,.16)}'+
'.tv-strip>div{max-width:1280px;margin:0 auto;padding:12px 32px;display:flex;justify-content:space-between;gap:16px;font-size:9px;letter-spacing:.14em;color:'+MUT+'}'+
'.tv-strip span+span{margin-left:24px}'+
'}'+
'@media screen and (max-width:767px){'+
'.tv-cols{grid-template-columns:1fr 1fr;padding:32px 16px;gap:28px}.tv-cols>div:first-child{grid-column:1/-1}'+
'.tv-word{padding:36px 12px 16px}.tv-sub{flex-direction:column;align-items:center;gap:6px;font-size:10px}'+
'.tv-strip>div{padding:12px 16px;flex-direction:column;gap:6px}.tv-strip .tv-x{display:none}}'+
'@media print{.tv-hdr,.tv-ftr{display:none!important}}';
var shCss='@media screen{'+
':host{display:block}'+
'*{box-sizing:border-box;margin:0;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif}'+
'.bar{position:fixed;top:calc(10px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);width:min(1120px,calc(100% - 20px));z-index:50;border:1px solid rgba(255,255,255,.22);border-radius:999px;background:linear-gradient(135deg,rgba(255,255,255,.16),rgba(255,255,255,.06) 55%,rgba(255,255,255,.10));-webkit-backdrop-filter:blur(16px) saturate(160%);backdrop-filter:blur(16px) saturate(160%);box-shadow:0 12px 34px rgba(4,10,26,.35)}'+
'.in{max-width:1280px;margin:0 auto;height:56px;padding:0 12px 0 20px;display:flex;align-items:center;justify-content:space-between;gap:16px}'+
'.brand{display:flex;align-items:center;flex:none;text-decoration:none}.brand img{height:30px;width:auto;display:block}'+
'.nav{display:flex;align-items:center;gap:32px}'+
'.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}'+
'.nav a{font-size:11px;letter-spacing:.14em;color:'+MUT+';text-decoration:none}.nav a:hover{color:'+GOLD2+'}'+
'.clock{display:flex;align-items:center;gap:8px;font-size:10px;color:'+MUT+'}'+
'.dot{width:4px;height:4px;border-radius:50%;background:'+GOLD2+';animation:tvp 2s infinite}@keyframes tvp{50%{opacity:.35}}'+
'.r{display:flex;align-items:center;gap:8px}'+
'.pill{height:32px;display:inline-flex;align-items:center;border:1px solid rgba(255,255,255,.28);background:rgba(255,255,255,.08);border-radius:999px;padding:0 16px;font-size:12px;font-weight:500;color:'+INK+';text-decoration:none;white-space:nowrap;cursor:pointer}'+
'.pill:hover{border-color:'+GOLD2+';color:'+GOLD2+'}'+
'.pill.count{font-size:11px;letter-spacing:.08em;font-weight:400}'+
'.pill.go{background:linear-gradient(135deg,'+GOLD2+','+GOLD1+');border-color:transparent;color:#1d1405;font-weight:600}'+
'.pill.go:hover{color:#1d1405;filter:brightness(1.06)}'+
'.burger{display:none;width:38px;height:38px;border:1px solid rgba(255,255,255,.28);background:rgba(255,255,255,.08);border-radius:10px;color:'+INK+';font-size:17px;line-height:1;cursor:pointer;align-items:center;justify-content:center}'+
'.mmenu{display:none;position:absolute;top:calc(100% + 8px);left:0;right:0;border:1px solid rgba(255,255,255,.22);border-radius:22px;background:rgba(14,31,66,.97);-webkit-backdrop-filter:blur(16px);backdrop-filter:blur(16px);padding:14px 16px 18px;box-shadow:0 12px 34px rgba(4,10,26,.35)}'+
'.mmenu .grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;max-width:420px;margin:0 auto}'+
'.mmenu .pill{height:44px;justify-content:center;font-size:14px}'+
'.mmenu .links{display:flex;justify-content:center;gap:22px;margin-top:14px}'+
'.mmenu .links a{font-size:10px;letter-spacing:.14em;color:'+MUT+';text-decoration:none}.mmenu .links a:hover{color:'+GOLD2+'}'+
'.bar.open{border-radius:28px}.bar.open .mmenu{display:block}'+
'}'+
'@media screen and (max-width:900px){.nav{display:none}.r{display:none}.burger{display:inline-flex}}'+
'@media(max-width:1100px){.pill.count{display:none}}'+
'@media print{.bar{display:none!important}}';
function el(t,c,h){var e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function clock(){try{return new Date().toLocaleTimeString('en-GB',{timeZone:'Asia/Kolkata',hour12:false})+' IST'}catch(e){return ''}}
function build(){
 if(document.querySelector('.tv-hdr'))return;
 var st=el('style');st.id='tv-shell-css';st.textContent=css;document.head.appendChild(st);
 var H=el('div','tv-hdr');var sr=H.attachShadow({mode:'open'});
 sr.innerHTML='<style>'+shCss+'</style><div class="bar"><div class="in">'+
 '<a href="/" class="brand"><img src="'+GOLD+'" alt="TAARV"></a>'+
 '<nav class="nav mono"><a href="/#factory">FACTORY_FLOOR</a><a href="/manifesto/">MANIFESTO</a><span class="clock mono"><span class="dot"></span><span id="tv-clk">'+clock()+'</span></span></nav>'+
 '<button class="burger" type="button" aria-label="Open menu" aria-expanded="false">&#9776;</button>'+
 '<div class="r">'+
 '<button class="pill" type="button" data-go="/#factory">Search</button>'+
 '<span class="pill count mono">'+COUNT+' TOOLS</span>'+
 '<a class="pill" href="'+PACKAGES+'">Packages</a>'+
 '<a class="pill tv-acct-chip" href="/account/">Sign in</a>'+
 '<a class="pill go" href="/">Enter</a>'+
 '</div></div>'+
 '<div class="mmenu"><div class="grid">'+
 '<button class="pill" type="button" data-go="/#factory">Search</button>'+
 '<a class="pill" href="'+PACKAGES+'">Packages</a>'+
 '<a class="pill tv-acct-chip" href="/account/">Sign in</a>'+
 '<a class="pill go" href="/">Enter</a>'+
 '</div><div class="links mono"><a href="/#factory">FACTORY_FLOOR</a><a href="/manifesto/">MANIFESTO</a><a href="/privacy/">PRIVACY</a><a href="/terms/">TERMS</a></div></div>'+
 '</div>';
 var bar=sr.querySelector('.bar');
 sr.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-go]');if(b){location.href=b.getAttribute('data-go');return}var m=e.target.closest&&e.target.closest('.burger');if(m){var o=bar.classList.toggle('open');m.setAttribute('aria-expanded',o)}});
 document.documentElement.style.setProperty('--tv-hdr-pad','80px');
 var ps=document.createElement('style');ps.id='tv-pad';document.head.appendChild(ps);
 function fitPad(){var q=bar.getBoundingClientRect();var px=Math.max(80,Math.ceil(q.bottom)+10);ps.textContent='@media screen{body{padding-top:'+px+'px!important}}@media print{.tv-hdr,.tv-ftr{display:none!important}body{padding-top:0!important}}'}
 fitPad();window.addEventListener('resize',fitPad);window.addEventListener('load',fitPad);setTimeout(fitPad,400);setTimeout(fitPad,1500);if(window.ResizeObserver)new ResizeObserver(fitPad).observe(bar);
 var old=document.querySelectorAll('body>header,body>nav,body>.topbar,body>.top,body>.site-header');
 for(var i=0;i<old.length;i++){var o=old[i];if(o.classList.contains('tv-hdr')||o.id==='dock')continue;if(o.querySelector('h1,h2,canvas,input,textarea,select'))continue;o.style.display='none'}
 var wrapH=document.querySelectorAll('body>.wrap>header,body>main>header,body>div>header');
 for(var j=0;j<wrapH.length;j++){var w=wrapH[j];if(w.querySelector('h1,h2,canvas,input,textarea,select,button'))continue;if(w.querySelector('img,nav'))w.style.display='none'}
 document.body.insertBefore(H,document.body.firstChild);
 setInterval(function(){var c=H.shadowRoot.getElementById('tv-clk');if(c)c.textContent=clock()},1000);
 /* footer */
 var oldf=document.querySelectorAll('body>footer,body>.foot,main>footer,.wrap>footer,.wrap>.foot');
 for(var k=0;k<oldf.length;k++){var f=oldf[k];if(f.querySelector('input,textarea,select,button,canvas'))continue;f.style.display='none'}
 var F=el('footer','tv-ftr');
 F.innerHTML='<div class="tv-cols"><div><a href="/"><img src="'+GOLD+'" alt="TAARV" style="height:34px;width:auto;display:block"></a><p>Ultra-premium tool factory. Minimal, industrial, precise. Built for people who make things.</p></div>'+
 '<div><h4 class="tv-mono">MACHINES</h4><ul><li><a href="/#factory">All '+COUNT+' Tools</a></li><li><a href="'+PACKAGES+'">Packages</a></li></ul></div>'+
 '<div><h4 class="tv-mono">FACTORY</h4><ul><li><a href="/manifesto/">Manifesto</a></li><li><a href="/privacy/">Privacy</a></li><li><a href="/terms/">Terms</a></li><li><a href="mailto:support@taarv.com">Contact</a></li></ul></div></div>'+
 '<div class="tv-word"><img src="'+GOLD+'" alt="TAARV"><div class="tv-sub tv-mono"><span>THE TOOL FACTORY</span><span>'+COUNT+' MACHINES - ONE FACTORY</span></div></div>'+
 '<div class="tv-strip"><div class="tv-mono"><div style="display:flex;padding:0;max-width:none;margin:0"><span>\u00a9 2026 TAARV</span><span class="tv-x">MADE IN THE FACTORY</span></div><span>'+COUNT+' TOOLS \u2014 BUILD 2.0</span></div></div>';
 F.querySelector('.tv-cols').style.borderTop='1px solid rgba(255,255,255,.12)';document.body.appendChild(F);document.documentElement.style.overflowX='clip';try{var cs=getComputedStyle(document.body);F.style.marginBottom='-'+cs.paddingBottom}catch(e){}
 /* NEUTRAL GLASS (approved palette): warm pearl base, soft navy/gold glow, clear glass cards in front */
 (function(){var gl=document.createElement('style');gl.id='tv-glass';gl.textContent=
 '@media screen{html.tv-glass:root:root:root:root:root{background-color:#10234a!important;background-image:radial-gradient(55vmax 45vmax at 8% -8%,rgba(240,191,78,.12),transparent 62%),radial-gradient(50vmax 42vmax at 96% 6%,rgba(96,140,220,.14),transparent 62%),radial-gradient(55vmax 45vmax at 80% 105%,rgba(240,191,78,.10),transparent 60%),radial-gradient(45vmax 40vmax at -4% 92%,rgba(96,140,220,.12),transparent 60%),linear-gradient(180deg,#10234a,#0e1f42 78%)!important;background-attachment:fixed!important}'+
 'html.tv-glass body:not(#tvx):not(#tvy):not(#tvz){background:transparent!important}'+
 'html.tv-glass :is(.card,.panel,.pnl,.box,.side,.stage,.dock,.bar){background:linear-gradient(135deg,rgba(255,255,255,.97),rgba(245,247,251,.94) 45%,rgba(250,251,253,.96))!important;border:1px solid rgba(255,255,255,.85)!important;-webkit-backdrop-filter:blur(10px) saturate(190%);backdrop-filter:blur(10px) saturate(190%);box-shadow:inset 0 1.5px 0 rgba(255,255,255,.95),inset 0 -1px 0 rgba(255,255,255,.5),inset 0 0 18px rgba(255,255,255,.35),0 1px 2px rgba(20,20,40,.06),0 18px 44px rgba(40,40,90,.14)!important}'+
 'html.tv-glass :is(input[type=text],input[type=number],input[type=email],input[type=tel],input[type=date],textarea,select){background:rgba(255,255,255,.55)!important;border:1px solid rgba(255,255,255,.9)!important;box-shadow:inset 0 1px 2px rgba(20,20,40,.1)!important}'+
 'html.tv-glass :is(.chips button,.mini,.seg){background:linear-gradient(160deg,rgba(255,255,255,.8),rgba(255,255,255,.4))!important;border:1px solid rgba(255,255,255,.9)!important;box-shadow:inset 0 1px 0 #fff,0 2px 8px rgba(20,20,40,.08)!important}'+
 'html.tv-glass :is(body>h1,.wrap>h1,.top>h1,main>h1){color:#f5f2ec}html.tv-glass :is(.wrap>.sub,.top>p,main>.sub){color:#b6c3da}'+
 'html.tv-info body,html.tv-info main,html.tv-info h1,html.tv-info h2{color:#f5f2ec}html.tv-info .meta,html.tv-info footer{color:#b6c3da}html.tv-info main>.card{color:#243049}html.tv-info a{color:#f0bf4e}'+
 '.tv-ftr{background:'+NAVY2+'!important;box-shadow:none!important;border:none!important}.tv-ftr .tv-cols,.tv-ftr .tv-word{background:transparent!important}}';
 gl.textContent+="@media screen{\nhtml.tv-glass body :is(.glass,.bm-glass,.bc-glass,.ct-glass,.kp-glass,.iv-glass,.io-glass,.st-glass,.pd-glass,.cm-glass,.tm-glass,.pp-glass,.ml-glass,.gd-glass,.tk-panel){background:linear-gradient(135deg,#fafbfd,#f0f3f8)!important;border-color:#d7deeb!important;color:#243049!important}\nhtml.tv-glass body :is(#bm-top,#bc-brand,#fc-top,.tk-top,#ct-top,#sp-top,#kp-head,#io-top,#pd-top,#cm-top,#ml-top,#pp-top,.wrap>header,.app>header.top,.hd,.top):not(.glass):not(.iv-glass) h1{color:#f5f2ec!important}\nhtml.tv-glass body :is(#bm-top,#bc-brand,#fc-top,.tk-top,#ct-top,#sp-top,#kp-head,#io-top,#pd-top,#cm-top,#ml-top,#pp-top,.wrap>header,.app>header.top,.hd,.top):not(.glass):not(.iv-glass) :is(p,.sub,.eyebrow,[class$=\"-eyebrow\"],.status){color:#b6c3da!important}\nhtml.tv-glass body :is(button.btn,button[class$=\"-gold\"],button[class$=\"-main\"],button[id*=\"sample\" i],nav button.active,nav button.on,nav button[aria-selected=\"true\"],button[aria-pressed=\"true\"],.seg button.on,.seg button.sel,.tabs button.on,.viewtabs button.on):not(:disabled){background:linear-gradient(135deg,#f0bf4e,#c4861a)!important;color:#271b08!important;border-color:#d8a535!important;box-shadow:inset 0 1px 0 #ffe7a3,0 2px 7px #0001!important}\nhtml.tv-redirect body{display:flex!important;flex-direction:column!important;align-items:center!important;justify-content:flex-start!important}\nhtml.tv-redirect body>.card{margin:65px 20px 15px!important;max-width:400px!important;width:calc(100% - 40px);background:#192f55!important;border-color:#496080!important;color:#f5f2ec!important;flex-shrink:0}\nhtml.tv-redirect body>.card p{color:#c2cee1!important}html.tv-redirect .tv-ftr{margin-left:0!important;flex-shrink:0}\n}"; gl.textContent+="@media screen{\nhtml.tv-glass:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body :is(.glass,.bm-glass,.bc-glass,.ct-glass,.kp-glass,.iv-glass,.io-glass,.st-glass,.pd-glass,.cm-glass,.tm-glass,.pp-glass,.ml-glass,.gd-glass,.tk-panel,#fc-drop){background:linear-gradient(135deg,#fafbfd,#f0f3f8)!important;border-color:#d7deeb!important;color:#243049!important}\nhtml.tv-glass:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body :is(#gd-top,#top:not(.glass),#pphead) h1{color:#f5f2ec!important}\nhtml.tv-glass:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body :is(#gd-top,#top:not(.glass),#pphead) :is(p,.eyebrow,[class$=\"-eyebrow\"]){color:#b6c3da!important}\nhtml.tv-glass:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body #gd-top{background:transparent!important;color:#f5f2ec!important}\nhtml.tv-glass:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body :is(button.btn,button.b.g,button[class$=\"-gold\"],button[class$=\"-main\"],button.main,button[id*=\"sample\" i],button[aria-selected=\"true\"],button[aria-pressed=\"true\"],button.active,button.on):not(:disabled):not(.pal):not(.sw):not(.tk-sw):not(.tp):not(.iv-preset):not(.look){background:linear-gradient(135deg,#f0bf4e,#c4861a)!important;color:#271b08!important;border-color:#d8a535!important;box-shadow:inset 0 1px 0 #ffe7a3,0 2px 7px #0001!important}\n}"; gl.textContent+="@media screen{html.tv-glass:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body button:disabled{background:#e5e9f0!important;color:#7d8799!important;border-color:#d3dae5!important;box-shadow:none!important}html.tv-glass body :is(#bm-foot,#fc-foot,.tk-foot,.io-footer){color:#b6c3da!important}}"; gl.textContent+="@media screen{html.tv-route-jobcard body header.hd{background:#f4f6fa!important}html.tv-route-jobcard:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body .hd h1{color:#243049!important}html.tv-route-jobcard:not(#tv-theme-a):not(#tv-theme-b):not(#tv-theme-c):not(#tv-theme-d):not(#tv-theme-e) body .hd p{color:#66748a!important}}"; gl.textContent+="@media screen{html.tv-info .manifesto-card{background:linear-gradient(135deg,#fafbfd,#f0f3f8)!important;color:#243049!important;border-color:#d7deeb!important}html.tv-info .manifesto-card :is(h2,.closing){color:#243049!important}html.tv-info .manifesto-card p{color:#47546a!important}html.tv-info :is(.manifesto-top .eyebrow,.manifesto-bottom span,.preview-note){color:#b6c3da!important}html.tv-info .manifesto-bottom a{background:linear-gradient(135deg,#f0bf4e,#c4861a)!important;color:#271b08!important}}"; document.head.appendChild(gl);document.documentElement.classList.add('tv-glass');document.documentElement.classList.add('tv-route-'+location.pathname.replace(/^\/+|\/+$/g,'').replace(/[^a-z0-9-]/gi,''));if(/^(account|pricing|login)$/.test(location.pathname.replace(/^\/+|\/+$/g,'')))document.documentElement.classList.add('tv-redirect');if(/^(privacy|terms|manifesto)$/.test(location.pathname.replace(/^\/+|\/+$/g,'')))document.documentElement.classList.add('tv-info');})();

}
if(document.body)build();else document.addEventListener('DOMContentLoaded',build);
window.addEventListener('load',build);
})();

/* TAARV design system loader: restyles the classic tool pages (grey grid, mono labels) into the premium skin. */
(function(){try{
 var OLD=' govdoc datawipe photocover pixelclean ';
 var slug=location.pathname.replace(/^\/+|\/+$/g,'').split('/')[0];
 if(OLD.indexOf(' '+slug+' ')<0)return;
 var done=0;function go(){if(done||!document.body)return;done=1;document.documentElement.classList.add('tv-ds');
  var l=document.createElement('link');l.rel='stylesheet';l.href='/taarv-ds.css?v=5';document.head.appendChild(l);}
 go();
}catch(e){}})();
