/* TAARV shared shell: header + footer for every tool page. One place for the live tool count. */
(function(){
if(window.__taarvShell)return;window.__taarvShell=1;
var COUNT=34;try{var _t=document.createElement('script');_t.src='/taarv-text.js?v=1';document.head.appendChild(_t)}catch(e){} /* <- the ONLY place the tool count lives for tool pages */
var LIGHT='/taarv-master-light.png?v=master-20261011-r1';
var css='@media screen{'+
'.tv-hdr{position:sticky;top:0;z-index:2147483000;background:rgba(251,251,253,.86);-webkit-backdrop-filter:saturate(180%) blur(14px);backdrop-filter:saturate(180%) blur(14px);border-bottom:1px solid #e8e8ec;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;color:#1d1d1f}'+
'.tv-hdr *{box-sizing:border-box}'+
'.tv-in{max-width:1280px;margin:0 auto;height:56px;padding:0 32px;display:flex;align-items:center;justify-content:space-between;gap:16px}'+
'.tv-brand{display:flex;align-items:center;flex:none}.tv-brand img{height:30px;width:auto;display:block}'+
'.tv-nav{display:flex;align-items:center;gap:32px}'+
'.tv-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}'+
'.tv-nav a{font-size:11px;letter-spacing:.14em;color:#6e6e73;text-decoration:none}.tv-nav a:hover{color:#000}'+
'.tv-clock{display:flex;align-items:center;gap:8px;font-size:10px;color:#86868b}.tv-dot{width:4px;height:4px;border-radius:50%;background:#00c950;animation:tvp 2s infinite}@keyframes tvp{50%{opacity:.35}}'+
'.tv-r{display:flex;align-items:center;gap:8px}'+
'.tv-pill{height:32px;display:inline-flex;align-items:center;border:1px solid #d9d9de;background:#fff;border-radius:999px;padding:0 16px;font-size:12px;font-weight:500;color:#1d1d1f;text-decoration:none;white-space:nowrap}.tv-pill:hover{border-color:#000}'+
'.tv-pill.tv-count{font-size:11px;letter-spacing:.08em;font-weight:400}'+
'.tv-dm{display:none;font-size:10px;letter-spacing:.08em;font-weight:400}.tv-pill.tv-go{background:#000;border-color:#000;color:#fff;font-weight:600}.tv-pill.tv-go:hover{background:#1a1a1a}'+
'.tv-demo{display:flex;justify-content:flex-end;max-width:1280px;margin:0 auto;padding:0 32px 8px}.tv-demo a{font-size:10px;letter-spacing:.1em;color:#6e6e73;text-decoration:none;border:1px solid #d9d9de;border-radius:999px;padding:6px 13px;background:#fff}'+
'.tv-ftr{margin-top:56px;border-top:1px solid #e8e8ec;background:#fbfbfd;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif;color:#1d1d1f;position:relative;z-index:1}.tv-ftr *{box-sizing:border-box}'+
'.tv-cols{max-width:1280px;margin:0 auto;padding:48px 32px;display:grid;grid-template-columns:1.5fr 1fr 1fr;gap:40px;background:#fff}'+
'.tv-cols p{font-size:13px;line-height:1.6;color:#6e6e73;max-width:280px;margin:14px 0 0}'+
'.tv-cols h4{font-size:10px;letter-spacing:.18em;color:#6e6e73;margin:0 0 16px;font-weight:500}.tv-cols ul{list-style:none;margin:0;padding:0}.tv-cols li{font-size:13px;line-height:1.4;margin:0 0 8px}.tv-cols a{color:#1d1d1f;text-decoration:none}.tv-cols a:hover{text-decoration:underline}'+
'.tv-word{border-top:1px solid #e8e8ec;padding:56px 16px 24px;text-align:center;overflow:hidden}.tv-word img{display:block;width:min(830px,92%);height:auto;margin:0 auto}'+
'.tv-sub{display:flex;justify-content:center;gap:24px;margin-top:18px;font-size:11px;letter-spacing:.22em;color:#6e6e73}'+
'.tv-strip{border-top:1px dashed #d9d9de}.tv-strip>div{max-width:1280px;margin:0 auto;padding:12px 32px;display:flex;justify-content:space-between;gap:16px;font-size:9px;letter-spacing:.14em;color:#86868b}.tv-strip span+span{margin-left:24px}'+
'}'+
'@media screen and (max-width:767px){.tv-dm{display:inline-flex}.tv-in{height:auto;padding:10px 16px 6px;flex-wrap:wrap}.tv-nav{display:none}.tv-brand img{height:26px}'+
'.tv-r{order:3;width:calc(100% + 32px);margin:0 -16px;padding:4px 16px 8px;overflow-x:auto;white-space:nowrap;-webkit-overflow-scrolling:touch;scrollbar-width:none}.tv-r::-webkit-scrollbar{display:none}'+
'.tv-go{position:absolute;right:16px;top:10px;height:34px}.tv-demo{display:none}'+
'.tv-cols{grid-template-columns:1fr 1fr;padding:32px 16px;gap:28px}.tv-cols>div:first-child{grid-column:1/-1}.tv-word{padding:36px 12px 16px}.tv-sub{flex-direction:column;align-items:center;gap:6px;font-size:10px}.tv-strip>div{padding:12px 16px;flex-direction:column;gap:6px}.tv-strip .tv-x{display:none}}'+
'@media print{.tv-hdr,.tv-ftr{display:none!important}}';
function el(t,c,h){var e=document.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e}
function clock(){try{return new Date().toLocaleTimeString('en-GB',{timeZone:'Asia/Kolkata',hour12:false})+' IST'}catch(e){return ''}}
function build(){
 if(document.querySelector('.tv-hdr'))return;
 var st=el('style');st.id='tv-shell-css';st.textContent=css;document.head.appendChild(st);
 var H=el('header','tv-hdr');
 H.innerHTML='<div class="tv-in"><a class="tv-brand" href="/"><img src="'+LIGHT+'" alt="TAARV - The Tool Factory"></a>'+
 '<nav class="tv-nav"><a class="tv-mono" href="/#factory">FACTORY_FLOOR</a><a class="tv-mono" href="/manifesto/">MANIFESTO</a><div class="tv-clock tv-mono"><span class="tv-dot"></span><span id="tv-clk">'+clock()+'</span></div></nav>'+
 '<div class="tv-r"><a class="tv-pill" href="/#factory" aria-label="Search all '+COUNT+' tools">Search</a><a class="tv-pill tv-count tv-mono" href="/#factory">'+COUNT+' READY \u2022 LOCAL TOOLS</a><a class="tv-pill" href="/pricing/">Packages</a><a class="tv-pill" href="/login/">Login</a><a class="tv-pill tv-mono tv-dm" href="/usage-demo/">DEMO \u00b7 2 FREE USES LEFT \u2197</a><a class="tv-pill tv-go" href="/">Enter</a></div></div>'+
 '<div class="tv-demo"><a class="tv-mono" href="/usage-demo/">DEMO \u00b7 2 FREE USES LEFT \u2197</a></div>';
 /* hide the page\'s own top bar so there is only one header */
 var old=document.querySelectorAll('body>header,body>nav,body>.topbar,body>.top,body>.site-header');
 for(var i=0;i<old.length;i++){var o=old[i];if(o.classList.contains('tv-hdr'))continue;if(o.querySelector('h1,h2,canvas,input,textarea,select'))continue;o.style.display='none'}
 var wrapH=document.querySelectorAll('body>.wrap>header,body>main>header,body>div>header');
 for(var j=0;j<wrapH.length;j++){var w=wrapH[j];if(w.querySelector('h1,h2,canvas,input,textarea,select,button'))continue;if(w.querySelector('img,nav'))w.style.display='none'}
 document.body.insertBefore(H,document.body.firstChild);
 setInterval(function(){var c=document.getElementById('tv-clk');if(c)c.textContent=clock()},1000);
 /* footer */
 var oldf=document.querySelectorAll('body>footer,body>.foot,main>footer,.wrap>footer,.wrap>.foot');
 for(var k=0;k<oldf.length;k++){var f=oldf[k];if(f.querySelector('input,textarea,select,button,canvas'))continue;f.style.display='none'}
 var F=el('footer','tv-ftr');
 F.innerHTML='<div class="tv-cols"><div><a href="/"><img src="'+LIGHT+'" alt="TAARV" style="height:34px;width:auto;display:block"></a><p>Ultra-premium tool factory. Minimal, industrial, precise. Built for people who make things.</p></div>'+
 '<div><h4 class="tv-mono">MACHINES</h4><ul><li><a href="/#factory">All '+COUNT+' Tools</a></li><li><a href="/#factory">New Releases</a></li><li><a href="/#factory">Changelog</a></li><li><a href="/#factory">Roadmap</a></li></ul></div>'+
 '<div><h4 class="tv-mono">FACTORY</h4><ul><li><a href="/manifesto/">Manifesto</a></li><li>System Status</li><li>Privacy (Local-only)</li><li>Contact</li></ul></div></div>'+
 '<div class="tv-word"><img src="'+LIGHT+'" alt="TAARV"><div class="tv-sub tv-mono"><span>THE TOOL FACTORY</span><span>'+COUNT+' MACHINES - ONE FACTORY</span></div></div>'+
 '<div class="tv-strip"><div class="tv-mono"><div style="display:flex;padding:0;max-width:none;margin:0"><span>\u00a9 2026 TAARV</span><span class="tv-x">MADE IN THE FACTORY</span></div><span>'+COUNT+' READY / LOCAL TOOLS \u2014 BUILD 2.0</span></div></div>';
 document.body.appendChild(F);
}
if(document.body)build();else document.addEventListener('DOMContentLoaded',build);
window.addEventListener('load',build);
})();
